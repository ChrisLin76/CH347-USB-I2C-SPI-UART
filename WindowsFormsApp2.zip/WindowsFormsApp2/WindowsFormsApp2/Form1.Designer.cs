﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button_I2C_Write = new System.Windows.Forms.Button();
            this.button_I2C_Read = new System.Windows.Forms.Button();
            this.button_GPIO_Set = new System.Windows.Forms.Button();
            this.button_GPIO_Get = new System.Windows.Forms.Button();
            this.button_SPI_Read = new System.Windows.Forms.Button();
            this.button_SPI_Write = new System.Windows.Forms.Button();
            this.button_UART_Write = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(116, 41);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Open Device";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(116, 84);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Close Device";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 168);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button_I2C_Write
            // 
            this.button_I2C_Write.Location = new System.Drawing.Point(258, 41);
            this.button_I2C_Write.Name = "button_I2C_Write";
            this.button_I2C_Write.Size = new System.Drawing.Size(75, 23);
            this.button_I2C_Write.TabIndex = 3;
            this.button_I2C_Write.Text = "I2C Write";
            this.button_I2C_Write.UseVisualStyleBackColor = true;
            this.button_I2C_Write.Click += new System.EventHandler(this.button_I2C_Write_Click);
            // 
            // button_I2C_Read
            // 
            this.button_I2C_Read.Location = new System.Drawing.Point(258, 84);
            this.button_I2C_Read.Name = "button_I2C_Read";
            this.button_I2C_Read.Size = new System.Drawing.Size(75, 23);
            this.button_I2C_Read.TabIndex = 4;
            this.button_I2C_Read.Text = "I2C Read";
            this.button_I2C_Read.UseVisualStyleBackColor = true;
            this.button_I2C_Read.Click += new System.EventHandler(this.button_I2C_Read_Click);
            // 
            // button_GPIO_Set
            // 
            this.button_GPIO_Set.Location = new System.Drawing.Point(378, 41);
            this.button_GPIO_Set.Name = "button_GPIO_Set";
            this.button_GPIO_Set.Size = new System.Drawing.Size(75, 23);
            this.button_GPIO_Set.TabIndex = 5;
            this.button_GPIO_Set.Text = "GPIO Set";
            this.button_GPIO_Set.UseVisualStyleBackColor = true;
            this.button_GPIO_Set.Click += new System.EventHandler(this.button_GPIO_Set_Click);
            // 
            // button_GPIO_Get
            // 
            this.button_GPIO_Get.Location = new System.Drawing.Point(378, 84);
            this.button_GPIO_Get.Name = "button_GPIO_Get";
            this.button_GPIO_Get.Size = new System.Drawing.Size(75, 23);
            this.button_GPIO_Get.TabIndex = 6;
            this.button_GPIO_Get.Text = "GPIO Get ";
            this.button_GPIO_Get.UseVisualStyleBackColor = true;
            this.button_GPIO_Get.Click += new System.EventHandler(this.button_GPIO_Get_Click);
            // 
            // button_SPI_Read
            // 
            this.button_SPI_Read.Location = new System.Drawing.Point(499, 84);
            this.button_SPI_Read.Name = "button_SPI_Read";
            this.button_SPI_Read.Size = new System.Drawing.Size(75, 23);
            this.button_SPI_Read.TabIndex = 8;
            this.button_SPI_Read.Text = "SPI Read";
            this.button_SPI_Read.UseVisualStyleBackColor = true;
            this.button_SPI_Read.Click += new System.EventHandler(this.button_SPI_Read_Click);
            // 
            // button_SPI_Write
            // 
            this.button_SPI_Write.Location = new System.Drawing.Point(499, 41);
            this.button_SPI_Write.Name = "button_SPI_Write";
            this.button_SPI_Write.Size = new System.Drawing.Size(75, 23);
            this.button_SPI_Write.TabIndex = 7;
            this.button_SPI_Write.Text = "SPI Write";
            this.button_SPI_Write.UseVisualStyleBackColor = true;
            this.button_SPI_Write.Click += new System.EventHandler(this.button_SPI_Write_Click);
            // 
            // button_UART_Write
            // 
            this.button_UART_Write.Location = new System.Drawing.Point(627, 41);
            this.button_UART_Write.Name = "button_UART_Write";
            this.button_UART_Write.Size = new System.Drawing.Size(106, 23);
            this.button_UART_Write.TabIndex = 9;
            this.button_UART_Write.Text = "UART Write";
            this.button_UART_Write.UseVisualStyleBackColor = true;
            this.button_UART_Write.Click += new System.EventHandler(this.button_UART_Write_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 231);
            this.Controls.Add(this.button_UART_Write);
            this.Controls.Add(this.button_SPI_Read);
            this.Controls.Add(this.button_SPI_Write);
            this.Controls.Add(this.button_GPIO_Get);
            this.Controls.Add(this.button_GPIO_Set);
            this.Controls.Add(this.button_I2C_Read);
            this.Controls.Add(this.button_I2C_Write);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button_I2C_Write;
        private System.Windows.Forms.Button button_I2C_Read;
        private System.Windows.Forms.Button button_GPIO_Set;
        private System.Windows.Forms.Button button_GPIO_Get;
        private System.Windows.Forms.Button button_SPI_Read;
        private System.Windows.Forms.Button button_SPI_Write;
        private System.Windows.Forms.Button button_UART_Write;
    }
}

