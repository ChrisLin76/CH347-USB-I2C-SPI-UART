﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label_Class = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button_I2C_Write = new System.Windows.Forms.Button();
            this.button_I2C_Read = new System.Windows.Forms.Button();
            this.button_GPIO_Set = new System.Windows.Forms.Button();
            this.button_GPIO_Get = new System.Windows.Forms.Button();
            this.button_SPI_Read = new System.Windows.Forms.Button();
            this.button_SPI_Write = new System.Windows.Forms.Button();
            this.button_UART_Write = new System.Windows.Forms.Button();
            this.label_Fun_Type = new System.Windows.Forms.Label();
            this.label_ID = new System.Windows.Forms.Label();
            this.label_Chip_Mode = new System.Windows.Forms.Label();
            this.label_USB_Speed = new System.Windows.Forms.Label();
            this.label_CH347IfNum = new System.Windows.Forms.Label();
            this.label_ProductString = new System.Windows.Forms.Label();
            this.label_ManufacturerString = new System.Windows.Forms.Label();
            this.label_FirmwareVer = new System.Windows.Forms.Label();
            this.label_Message = new System.Windows.Forms.Label();
            this.label_Index = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(116, 41);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Open Device";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(116, 84);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Close Device";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label_Class
            // 
            this.label_Class.AutoSize = true;
            this.label_Class.Location = new System.Drawing.Point(38, 181);
            this.label_Class.Name = "label_Class";
            this.label_Class.Size = new System.Drawing.Size(29, 12);
            this.label_Class.TabIndex = 2;
            this.label_Class.Text = "Class";
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button_I2C_Write
            // 
            this.button_I2C_Write.Location = new System.Drawing.Point(258, 41);
            this.button_I2C_Write.Name = "button_I2C_Write";
            this.button_I2C_Write.Size = new System.Drawing.Size(75, 23);
            this.button_I2C_Write.TabIndex = 3;
            this.button_I2C_Write.Text = "I2C Write";
            this.button_I2C_Write.UseVisualStyleBackColor = true;
            this.button_I2C_Write.Click += new System.EventHandler(this.button_I2C_Write_Click);
            // 
            // button_I2C_Read
            // 
            this.button_I2C_Read.Location = new System.Drawing.Point(258, 84);
            this.button_I2C_Read.Name = "button_I2C_Read";
            this.button_I2C_Read.Size = new System.Drawing.Size(75, 23);
            this.button_I2C_Read.TabIndex = 4;
            this.button_I2C_Read.Text = "I2C Read";
            this.button_I2C_Read.UseVisualStyleBackColor = true;
            this.button_I2C_Read.Click += new System.EventHandler(this.button_I2C_Read_Click);
            // 
            // button_GPIO_Set
            // 
            this.button_GPIO_Set.Location = new System.Drawing.Point(378, 41);
            this.button_GPIO_Set.Name = "button_GPIO_Set";
            this.button_GPIO_Set.Size = new System.Drawing.Size(75, 23);
            this.button_GPIO_Set.TabIndex = 5;
            this.button_GPIO_Set.Text = "GPIO Set";
            this.button_GPIO_Set.UseVisualStyleBackColor = true;
            this.button_GPIO_Set.Click += new System.EventHandler(this.button_GPIO_Set_Click);
            // 
            // button_GPIO_Get
            // 
            this.button_GPIO_Get.Location = new System.Drawing.Point(378, 84);
            this.button_GPIO_Get.Name = "button_GPIO_Get";
            this.button_GPIO_Get.Size = new System.Drawing.Size(75, 23);
            this.button_GPIO_Get.TabIndex = 6;
            this.button_GPIO_Get.Text = "GPIO Get ";
            this.button_GPIO_Get.UseVisualStyleBackColor = true;
            this.button_GPIO_Get.Click += new System.EventHandler(this.button_GPIO_Get_Click);
            // 
            // button_SPI_Read
            // 
            this.button_SPI_Read.Location = new System.Drawing.Point(499, 84);
            this.button_SPI_Read.Name = "button_SPI_Read";
            this.button_SPI_Read.Size = new System.Drawing.Size(75, 23);
            this.button_SPI_Read.TabIndex = 8;
            this.button_SPI_Read.Text = "SPI Read";
            this.button_SPI_Read.UseVisualStyleBackColor = true;
            this.button_SPI_Read.Click += new System.EventHandler(this.button_SPI_Read_Click);
            // 
            // button_SPI_Write
            // 
            this.button_SPI_Write.Location = new System.Drawing.Point(499, 41);
            this.button_SPI_Write.Name = "button_SPI_Write";
            this.button_SPI_Write.Size = new System.Drawing.Size(75, 23);
            this.button_SPI_Write.TabIndex = 7;
            this.button_SPI_Write.Text = "SPI Write";
            this.button_SPI_Write.UseVisualStyleBackColor = true;
            this.button_SPI_Write.Click += new System.EventHandler(this.button_SPI_Write_Click);
            // 
            // button_UART_Write
            // 
            this.button_UART_Write.Location = new System.Drawing.Point(627, 41);
            this.button_UART_Write.Name = "button_UART_Write";
            this.button_UART_Write.Size = new System.Drawing.Size(106, 23);
            this.button_UART_Write.TabIndex = 9;
            this.button_UART_Write.Text = "UART Write";
            this.button_UART_Write.UseVisualStyleBackColor = true;
            this.button_UART_Write.Click += new System.EventHandler(this.button_UART_Write_Click);
            // 
            // label_Fun_Type
            // 
            this.label_Fun_Type.AutoSize = true;
            this.label_Fun_Type.Location = new System.Drawing.Point(38, 202);
            this.label_Fun_Type.Name = "label_Fun_Type";
            this.label_Fun_Type.Size = new System.Drawing.Size(29, 12);
            this.label_Fun_Type.TabIndex = 10;
            this.label_Fun_Type.Text = "Type";
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.Location = new System.Drawing.Point(38, 226);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(46, 12);
            this.label_ID.TabIndex = 11;
            this.label_ID.Text = "VID/PID";
            // 
            // label_Chip_Mode
            // 
            this.label_Chip_Mode.AutoSize = true;
            this.label_Chip_Mode.Location = new System.Drawing.Point(38, 247);
            this.label_Chip_Mode.Name = "label_Chip_Mode";
            this.label_Chip_Mode.Size = new System.Drawing.Size(61, 12);
            this.label_Chip_Mode.TabIndex = 12;
            this.label_Chip_Mode.Text = "Chip_Mode";
            // 
            // label_USB_Speed
            // 
            this.label_USB_Speed.AutoSize = true;
            this.label_USB_Speed.Location = new System.Drawing.Point(38, 271);
            this.label_USB_Speed.Name = "label_USB_Speed";
            this.label_USB_Speed.Size = new System.Drawing.Size(61, 12);
            this.label_USB_Speed.TabIndex = 13;
            this.label_USB_Speed.Text = "USB_Speed";
            // 
            // label_CH347IfNum
            // 
            this.label_CH347IfNum.AutoSize = true;
            this.label_CH347IfNum.Location = new System.Drawing.Point(38, 294);
            this.label_CH347IfNum.Name = "label_CH347IfNum";
            this.label_CH347IfNum.Size = new System.Drawing.Size(70, 12);
            this.label_CH347IfNum.TabIndex = 13;
            this.label_CH347IfNum.Text = "CH347IfNum";
            // 
            // label_ProductString
            // 
            this.label_ProductString.AutoSize = true;
            this.label_ProductString.Location = new System.Drawing.Point(38, 330);
            this.label_ProductString.Name = "label_ProductString";
            this.label_ProductString.Size = new System.Drawing.Size(69, 12);
            this.label_ProductString.TabIndex = 13;
            this.label_ProductString.Text = "ProductString";
            // 
            // label_ManufacturerString
            // 
            this.label_ManufacturerString.AutoSize = true;
            this.label_ManufacturerString.Location = new System.Drawing.Point(38, 342);
            this.label_ManufacturerString.Name = "label_ManufacturerString";
            this.label_ManufacturerString.Size = new System.Drawing.Size(96, 12);
            this.label_ManufacturerString.TabIndex = 13;
            this.label_ManufacturerString.Text = "ManufacturerString";
            // 
            // label_FirmwareVer
            // 
            this.label_FirmwareVer.AutoSize = true;
            this.label_FirmwareVer.Location = new System.Drawing.Point(38, 354);
            this.label_FirmwareVer.Name = "label_FirmwareVer";
            this.label_FirmwareVer.Size = new System.Drawing.Size(66, 12);
            this.label_FirmwareVer.TabIndex = 13;
            this.label_FirmwareVer.Text = "FirmwareVer";
            // 
            // label_Message
            // 
            this.label_Message.AutoSize = true;
            this.label_Message.Location = new System.Drawing.Point(38, 131);
            this.label_Message.Name = "label_Message";
            this.label_Message.Size = new System.Drawing.Size(29, 12);
            this.label_Message.TabIndex = 14;
            this.label_Message.Text = "Class";
            // 
            // label_Index
            // 
            this.label_Index.AutoSize = true;
            this.label_Index.Location = new System.Drawing.Point(38, 160);
            this.label_Index.Name = "label_Index";
            this.label_Index.Size = new System.Drawing.Size(32, 12);
            this.label_Index.TabIndex = 2;
            this.label_Index.Text = "Index";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 427);
            this.Controls.Add(this.label_Message);
            this.Controls.Add(this.label_FirmwareVer);
            this.Controls.Add(this.label_ManufacturerString);
            this.Controls.Add(this.label_ProductString);
            this.Controls.Add(this.label_CH347IfNum);
            this.Controls.Add(this.label_USB_Speed);
            this.Controls.Add(this.label_Chip_Mode);
            this.Controls.Add(this.label_ID);
            this.Controls.Add(this.label_Fun_Type);
            this.Controls.Add(this.button_UART_Write);
            this.Controls.Add(this.button_SPI_Read);
            this.Controls.Add(this.button_SPI_Write);
            this.Controls.Add(this.button_GPIO_Get);
            this.Controls.Add(this.button_GPIO_Set);
            this.Controls.Add(this.button_I2C_Read);
            this.Controls.Add(this.button_I2C_Write);
            this.Controls.Add(this.label_Index);
            this.Controls.Add(this.label_Class);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label_Class;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button_I2C_Write;
        private System.Windows.Forms.Button button_I2C_Read;
        private System.Windows.Forms.Button button_GPIO_Set;
        private System.Windows.Forms.Button button_GPIO_Get;
        private System.Windows.Forms.Button button_SPI_Read;
        private System.Windows.Forms.Button button_SPI_Write;
        private System.Windows.Forms.Button button_UART_Write;
        private System.Windows.Forms.Label label_Fun_Type;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Label label_Chip_Mode;
        private System.Windows.Forms.Label label_USB_Speed;
        private System.Windows.Forms.Label label_CH347IfNum;
        private System.Windows.Forms.Label label_ProductString;
        private System.Windows.Forms.Label label_ManufacturerString;
        private System.Windows.Forms.Label label_FirmwareVer;
        private System.Windows.Forms.Label label_Message;
        private System.Windows.Forms.Label label_Index;
    }
}

