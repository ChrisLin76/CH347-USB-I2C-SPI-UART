﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Drawing.Text;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        SerialPort Serial_Port;

        public Thread Threadt;
        public bool Device_Open_Flag;

        CH347DLL.mPCH347_NOTIFY_ROUTINE NOTIFY_ROUTINE;//回调函数


        public UInt32 iWriteLength;
        public byte[] iWriteBuffer = new byte[64];
        public UInt32 iReadLength;
        public byte[] oReadBuffer = new byte[64];

        public byte GPIO_Dir;
        public byte GPIO_Data;



        public Form1()
        {
            InitializeComponent();

            Ini_iWriteBuffer();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //_DEV_INFOR DevInfR = new _DEV_INFOR();

            label1.Text = Convert.ToString(IntPtr.Size);
            UInt32 nRet;
            if (CH347DLL.CH347OpenDevice(0) != new IntPtr(-1))
            {
                this.Text = "CH347 Device Opened";
                label1.Text = "Open Done";
                Device_Open_Flag = true;

                try
                {

                    //if (CH347DLL.CH347GetDeviceInfor(0,ref DevInfR))
                    //{

                    //}

                }
                catch
                {

                };
            }
            else
            {
                label1.Text = "Opened Failed";
                Device_Open_Flag = false;
            }

            Set_I2C_Speed(3);
            /*
            //enable plug/unplug event 
            NOTIFY_ROUTINE = new CH347DLL.mPCH347_NOTIFY_ROUTINE(Device_Event);
            CH347DLL.CH347SetDeviceNotify(0, null, NOTIFY_ROUTINE);//设置监视通知
            */
        }

        private void Set_I2C_Speed(UInt32 speed_index)
        {
            if (CH347DLL.CH347I2C_Set(0, speed_index) == true)
            {
                label1.Text = "Set Speed done index- " + Convert.ToString(speed_index);
            }
        }

        public void Device_Event(UInt32 iEventStatus)//设备插拔事件, so far unplug cannnot work
        {
            int current = 0;//当前tab控件选中页的索引值

            if (iEventStatus == CH347DLL.CH347_DEVICE_ARRIVA)
            { // 设备插入事件,已经插入
                if (CH347DLL.CH347OpenDevice(0) == new IntPtr(-1))
                {
                    MessageBox.Show("Device Open Failed!");
                    Device_Open_Flag = false;
                    this.Text = "CH347 Device Offline";
                }
                else
                {
                    Device_Open_Flag = true; //打开成功
                    this.Text = "CH347 Device Online";
                }
            }
            else if (iEventStatus == CH347DLL.CH347_DEVICE_REMOVE)
            { // 设备拔出事件,已经拔出
                CH347DLL.CH347CloseDevice(0);
                Device_Open_Flag = false;
            }
        }

        private void I2C_Write(string DeviceAddress, string Address, string Data)
        {
            iWriteLength = 3;
            iReadLength = 0;

            iWriteBuffer[0] = 160;
            iWriteBuffer[1] = 00;
            iWriteBuffer[2] = 00;

            if (CH347DLL.CH347StreamI2C(0, iWriteLength, iWriteBuffer, iReadLength, oReadBuffer) == true)
            {
                label1.Text = "I2C Write Done";
            }
        }


        private void I2C_Read(string DeviceAddress, string Address, UInt32 ReadLenghth)
        {
            iWriteLength = 3;
            iReadLength = ReadLenghth;

            iWriteBuffer[0] = 164;
            iWriteBuffer[1] = 0;
            iWriteBuffer[2] = 0;

            if (CH347DLL.CH347StreamI2C(0, iWriteLength, iWriteBuffer, iReadLength, oReadBuffer) == true)
            {
                label1.Text = "I2C Read Done";
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            CH347DLL.CH347CloseDevice(0);
            label1.Text = "closed";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void button_I2C_Write_Click(object sender, EventArgs e)
        {
            I2C_Write("A0", "55", "87");
        }

        private void button_I2C_Read_Click(object sender, EventArgs e)
        {
            I2C_Read("A4", "0000", 32);
        }

        private void button_GPIO_Set_Click(object sender, EventArgs e)
        {
            CH347DLL.CH347GPIO_Set(0, 255, 255, 255);
            Thread.Sleep(200);
            CH347DLL.CH347GPIO_Set(0, 255, 255, 248);
            Thread.Sleep(200);
            CH347DLL.CH347GPIO_Set(0, 255, 255, 0);
        }

        private void button_GPIO_Get_Click(object sender, EventArgs e)
        {
            CH347DLL.CH347GPIO_Get(0, ref GPIO_Dir, ref GPIO_Data);
            label1.Text = Convert.ToString(GPIO_Data);
        }

        private void button_SPI_Write_Click(object sender, EventArgs e)
        {
            _SPI_CONFIG SPIcfg = new _SPI_CONFIG();
            SPIcfg.iMode = 0;
            SPIcfg.iClock = 0;
            SPIcfg.iByteOrder = 1;
            SPIcfg.iSpiWriteReadInterval = 100;
            SPIcfg.iSpiOutDefaultData = 0;
            SPIcfg.iChipSelect = 0;
            SPIcfg.CS1Polarity = 0;
            SPIcfg.CS2Polarity = 0;
            SPIcfg.iIsAutoDeativeCS = 0;
            SPIcfg.iActiveDelay = 0;
            SPIcfg.iDelayDeactive = 0;

            if (CH347DLL.CH347SPI_Init(0, ref SPIcfg))
            {
            };


            CH347DLL.CH347SPI_Write(0, 1, 8, 4, iWriteBuffer);
        }

        private void button_UART_Open_Ini_Click(object sender, EventArgs e)
        {
            //CH347DLL.CH347Uart_Open(0);
            //CH347DLL.CH347Uart_Init(0, 115200, 8, 1, 0, 10);
        }

        private void button_UART_Write_Click(object sender, EventArgs e)
        {
            try
            {
                Serial_Port = new SerialPort();

                if (Serial_Port.IsOpen)
                {
                    Serial_Port.Close();
                }

                Serial_Port.PortName = "COM4";
                Serial_Port.BaudRate = 7500000;//SPI/I2C Mode 7.5MHz Max. 
                Serial_Port.DataBits = 8;
                Serial_Port.StopBits = StopBits.One;

                if (!Serial_Port.IsOpen)
                {
                    Serial_Port.Open();

                    Serial_Port.Write(iWriteBuffer, 0, 8);

                    Threadt = new Thread(COM_Receive);

                }

            }
            catch
            {

            }
        }

        private void COM_Receive()
        {
            Byte[] buffer = new Byte[1024];

            try
            {
                if (Serial_Port.BytesToRead > 0)
                {
                    Int32 length = Serial_Port.Read(buffer, 0, buffer.Length);

                    string buf = Encoding.ASCII.GetString(buffer);

                    Array.Resize(ref buffer, length);
                }

                Thread.Sleep(20);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void Ini_iWriteBuffer()
        {
            iWriteBuffer[0] = 0x11;
            iWriteBuffer[1] = 0x22;
            iWriteBuffer[2] = 0x33;
            iWriteBuffer[3] = 0x44;
            iWriteBuffer[4] = 0x55;
            iWriteBuffer[5] = 0x66;
            iWriteBuffer[6] = 0x77;
            iWriteBuffer[7] = 0x88;

        }

        private void button_SPI_Read_Click(object sender, EventArgs e)
        {
            CH347DLL.CH347SPI_Read(0, 1, 2, 8, oReadBuffer);
        }
    }
}
